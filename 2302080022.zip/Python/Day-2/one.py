#write the syntax of conditional statement in python

a = 10
b = 20  

if a > b:
    print("a is greater than b")
elif a < b:
    print("a is less than b")
else:
    print("a is equal to b")