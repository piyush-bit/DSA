# wap to implement inheritance of the class netflix that contains child class netflix lite with the entities like user id then name device configuration , no of screens show type 
# if the suer is now signin with the current device and watching premimum show or live match broadcasting  then login in the account and no screen share is possivble at that time but after the user stop watching everythi upto 5 screen share is possible but when more than 5 device trying to login in that account then that user id will be freezed for the next 48 hours 
# wap a program in a way that the user can safely watch a premium show after 5 min depth 3 of his frend can watch any contain other than restricted contain that voilate the user id 



# wap using regex to validate a email address 