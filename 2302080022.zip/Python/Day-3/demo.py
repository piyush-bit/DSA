#wap to alter or modify the content of the list without using inbuuild function 
#wap to check weather a given list is a pallindrome or not 
