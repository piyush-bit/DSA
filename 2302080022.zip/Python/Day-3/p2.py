for i in range(1,6):
    print('*'*i,end='')
    print(' '*(2*(6-1-i)),end='')
    print('*'*i)
for i in range(4,0,-1):
    print('*'*i,end='')
    print(' '*(2*(6-1-i)),end='')
    print('*'*i)