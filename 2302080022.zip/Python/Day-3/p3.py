# wap to take in put from user in decimal and convert into it's bianry form 

decimal = int(input("Enter a decimal number: "))
binary = bin(decimal)
print("The binary representation of", decimal, "is", binary)