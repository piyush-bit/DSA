# a = {0,False,1,True,10.5,-7,2+5j,50.7,10.5}
# b = {"lkf","fds","adsf",1}
# c = a.copy()
# a-b|b-a == a^b
# print(a-b|b-a == a^b)

# dict = {
#     "abc":"abc",
#     True : False,
#     1:1,
# }

# print(len(dict))
# print(dict)

# # write a program to check weather a key already exist in the dictionary or not 
# if "1" in dict.keys():
#     print("yes")


# wap to find common element in 3 sets

# wap that inverts the keys and values in a dictionary . with multiple values have same value store the keys in a list 

# wap to check weather there are any duplicate values in a set

# wap to print all prime indexes of a list and store the index element in separate list 

# sruti arusi salman henry milan are 5 friends who planned for a trip to simpla . among them arusi fall in sick use list method 
# i. discard arusi from that list 
# ii. add rakesh and dibya to that list 
# iii. find the length of the list 
# iv. find th epostion of salman in the list 
# v. add your name in between second and third element adn print the final list using and skip one elemnet one beteween other two 


a, b = 0, 1
while a <= 50:
    print(a, end=" ")
    a, b = b, a + b
print()