class Average :
    def run(self,a,b,c):
        return (a+b+c)/3

ob = Average()
print(ob.run(20,30,40))

# wap to show the details abouthe student using class nad object
# wap to fetch the details about an employee using class and object 
# wap to show the details fo faculty member using class and object
#id ,salary ,position , no of exprerience , teaching subject 

